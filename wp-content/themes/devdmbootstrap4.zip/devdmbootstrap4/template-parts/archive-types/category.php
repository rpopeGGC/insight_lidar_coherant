<h1 class="dmbs-category-archive-title">
    <?php
    /* translators: %s: Name of post category */
    echo esc_html(sprintf( __("Currently Viewing Posts in %s","devdmbootstrap4"), single_term_title('',false)));
    ?>
</h1>