<h1 class="dmbs-category-archive-tag">
    <?php
        /* translators: %s: tag */
        echo esc_html(sprintf( __("Currently Viewing Posts Tagged %s","devdmbootstrap4"), single_term_title('',false)));
    ?>
</h1>