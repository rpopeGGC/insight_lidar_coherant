<?php if (get_theme_mod('devdmbootstrap4_show_credit_setting', 1)) : ?>

    <div class="container footer">
        <div class="row">
            <div class="col-12">

            </div>
        </div>
    </div>

<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
